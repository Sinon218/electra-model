Notebook chính sẽ sinh các file tokenized vào folder này.
