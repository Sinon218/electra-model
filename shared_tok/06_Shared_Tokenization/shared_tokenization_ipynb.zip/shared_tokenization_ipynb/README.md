# Bản dành cho Jupyter / Google Colab

Có 2 notebook:

1. `shared_tokenization_tweeteval.ipynb`
   - Trưởng nhóm chạy một lần.
   - Fit vocabulary trên train.
   - Sinh folder `artifacts/`.

2. `team_model_loader_template.ipynb`
   - Gửi cho từng người train model.
   - Chỉ load `artifacts/`.
   - Không tokenize lại.

## Cách dùng

### Trưởng nhóm
- Tạo folder `data/`
- Đặt:
  - `train.csv`
  - `validation.csv`
  - `test.csv`
- Mở `shared_tokenization_tweeteval.ipynb`
- Run All
- Gửi folder `artifacts/` cho team

### Người train model
- Đặt `artifacts/` cạnh notebook model
- Dùng `team_model_loader_template.ipynb`
- Bắt đầu xây model từ `Embedding`
